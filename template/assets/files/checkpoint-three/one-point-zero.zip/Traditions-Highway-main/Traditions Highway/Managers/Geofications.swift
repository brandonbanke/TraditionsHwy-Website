//
//  Geofications.swift
//  Traditions Highway
//
//  Created by Brandon Banke on 10/3/21.
//

import Foundation
